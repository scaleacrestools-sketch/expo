# ScaleAcres logo kit, Royal Gradient (v1.0, October 2026)

These are the approved logo files. For the usage rules, see *ScaleAcres Brand Guidelines* (chapters 02–06).

| Folder | Use |
|---|---|
| `01-primary` | **Default.** Black wordmark with the royal gradient symbol and strapline, for white and light backgrounds. Comes as the full lockup, no strapline (small sizes) and stacked (square formats). |
| `02-reversed` | For black and navy backgrounds: white wordmark, royal → sky symbol, sky strapline. |
| `03-one-colour` | Royal, black or white only, for one-colour print, embroidery, stamps, and use over photography or video. |
| `04-symbol` | The S-A building symbol on its own, for icons, avatars and accents. |
| `05-on-background` | Ready-made files with the logo already placed on Brand Black, Royal Navy or the royal gradient. |
| `06-icons` | App icon (SVG), favicon 32 px, Apple touch 180 px, Android 192/512 px and a 1080 px social avatar. |

- **SVG:** vector, for the web, print and any size.
- **PNG:** transparent background. Logos are 3000 px wide; symbols are 1024 px.

## Colours
| Colour | HEX |
|---|---|
| ScaleAcres Royal | `#1D4ED8` |
| Royal Deep | `#142E8C` |
| Sky | `#38BDF8` |
| Brand Black | `#0B0D0D` |
| White | `#FFFFFF` |

Gradient: `linear-gradient(60deg, #142E8C 0%, #1D4ED8 50%, #38BDF8 100%)`, rising from the base to the top.

## Rules in one line each
- **Clear space:** keep half of X clear on every side, where X is the cap height of SCALEACRES.
- **Minimum sizes:** full logo 240 px / 50 mm; without strapline 120 px / 25 mm; symbol 24 px / 6 mm.
- **Don't alter it:** never stretch, rotate, recolour, flip the gradient, add effects or rearrange the parts.

The files are vector traces of the supplied ScaleAcres artwork, recoloured to the approved Royal Gradient. If the original vector master (AI or EPS) exists, apply the same colours to it for large-format production.
