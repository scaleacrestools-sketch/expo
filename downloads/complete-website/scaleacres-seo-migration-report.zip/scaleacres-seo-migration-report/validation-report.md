# Validation report (static build, 19 Oct 2026)

| Check | Result |
|---|---|
| Static export | 345 HTML pages generated (331 live paths + homepage + new pages + 404) |
| SEO parity (per URL) | CONTENT 331 PASS · META 332 PASS · LINK 330 PASS / 2 REVIEW · SEO 331 PASS / 1 REVIEW (approved homepage) · 0 FAILED |
| Internal link crawl of the new build | 1 broken href, inside a blog article; it is broken on the live site too, and the article text is kept as written |
| Mobile 390 px, all pages | 344/344 without horizontal overflow, 0 page errors |
| Functional (desktop + mobile, 25 sampled pages of every template) | 16/16 pass |
| Homepage regression | 46/46 pass |
| TypeScript, ESLint | clean |

The scripts that produced these results are in the source ZIP:
- `scripts/legacy-extract.mjs`
- `scripts/seo-parity.py`
- `scripts/url-inventory.py`
