# SEO parity report — scaleacres.com → redesign (staging)

Live capture: 2026-10-19 · URLs compared: 334

| Check | PASS | REVIEW REQUIRED | FAILED | N/A |
|---|---|---|---|---|
| CONTENT | 331 | 1 | 0 | 2 |
| META | 332 | 0 | 0 | 2 |
| LINK | 330 | 2 | 0 | 2 |
| SEO | 331 | 1 | 0 | 2 |

| OLD URL | NEW URL | CONTENT STATUS | META STATUS | LINK STATUS | SEO STATUS | Notes |
|---|---|---|---|---|---|---|
| https://scaleacres.com/about-us/ | /about-us/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/au/ | /au/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/blog/ | /blog/ | PASS | PASS | PASS | PASS | capture covered 92% of the live page's visible words (forms/widgets) |
| https://scaleacres.com/blog/4-ps-of-marketing-in-real-estate/ | /blog/4-ps-of-marketing-in-real-estate/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/5-common-mistakes-real-estate-businesses-make-in-brand-marketing/ | /blog/5-common-mistakes-real-estate-businesses-make-in-brand-marketing/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/a-detailed-guide-to-real-estate-website-development/ | /blog/a-detailed-guide-to-real-estate-website-development/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/a-developer-spent-crores-on-ads-and-zero-on-branding-guess-what-happened/ | /blog/a-developer-spent-crores-on-ads-and-zero-on-branding-guess-what-happened/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/ai-real-estate-lead-generation/ | /blog/ai-real-estate-lead-generation/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/author/prem/ | /blog/author/prem/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/author/raghav/ | /blog/author/raghav/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/beginners-guide-to-facebook-ads-for-real-estate-agents/ | /blog/beginners-guide-to-facebook-ads-for-real-estate-agents/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/benefits-of-running-youtube-ads-for-real-estate-businesses/ | /blog/benefits-of-running-youtube-ads-for-real-estate-businesses/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/best-real-estate-lead-generation-platforms/ | /blog/best-real-estate-lead-generation-platforms/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/best-whatsapp-marketing-strategies-for-real-estate-agents-in-india/ | /blog/best-whatsapp-marketing-strategies-for-real-estate-agents-in-india/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/biggest-real-estate-marketing-mistakes-and-how-to-avoid-them/ | /blog/biggest-real-estate-marketing-mistakes-and-how-to-avoid-them/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/casestudy/our-case-one-goa/ | /blog/casestudy/our-case-one-goa/ | PASS | PASS | PASS | PASS | capture covered 93% of the live page's visible words (forms/widgets) |
| https://scaleacres.com/blog/category/branding/ | /blog/category/branding/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/category/digital-marketing/ | /blog/category/digital-marketing/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/category/facebook-ads/ | /blog/category/facebook-ads/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/category/lead-generation/ | /blog/category/lead-generation/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/category/ppc/ | /blog/category/ppc/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/category/seo/ | /blog/category/seo/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/category/social-media/ | /blog/category/social-media/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/category/uncategorized/ | /blog/category/uncategorized/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/category/website-development/ | /blog/category/website-development/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/common-challenges-in-real-estate-digital-marketing/ | /blog/common-challenges-in-real-estate-digital-marketing/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/common-challenges-in-real-estate-lead-generation-and-how-to-overcome-them/ | /blog/common-challenges-in-real-estate-lead-generation-and-how-to-overcome-them/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/common-google-ads-challenges-for-realtors/ | /blog/common-google-ads-challenges-for-realtors/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/common-mistakes-to-avoid-in-local-seo-for-real-estate-business/ | /blog/common-mistakes-to-avoid-in-local-seo-for-real-estate-business/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/common-seo-myths-every-realtor-should-stop-believing/ | /blog/common-seo-myths-every-realtor-should-stop-believing/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/custom-vs-template-real-estate-websites/ | /blog/custom-vs-template-real-estate-websites/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/digital-marketing-for-real-estate/ | /blog/digital-marketing-for-real-estate/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/elementskit-content/dynamic-content-megamenu-menuitem13/ | /blog/elementskit-content/dynamic-content-megamenu-menuitem13/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/elementskit-content/dynamic-content-megamenu-menuitem330/ | /blog/elementskit-content/dynamic-content-megamenu-menuitem330/ | PASS | PASS | PASS | PASS | capture covered 86% of the live page's visible words (forms/widgets) |
| https://scaleacres.com/blog/elementskit-content/dynamic-content-megamenu-menuitem3744/ | /blog/elementskit-content/dynamic-content-megamenu-menuitem3744/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/elementskit-content/dynamic-content-megamenu-menuitem6614/ | /blog/elementskit-content/dynamic-content-megamenu-menuitem6614/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/elementskit-content/dynamic-content-megamenu-menuitem6702/ | /blog/elementskit-content/dynamic-content-megamenu-menuitem6702/ | PASS | PASS | PASS | PASS | capture covered 86% of the live page's visible words (forms/widgets) |
| https://scaleacres.com/blog/elementskit-content/dynamic-content-widget-5be6639-6f0f7aa/ | /blog/elementskit-content/dynamic-content-widget-5be6639-6f0f7aa/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/google-ads-demand-gen-review-delays/ | /blog/google-ads-demand-gen-review-delays/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/google-ads-vs-meta-ads-for-real-estate-which-delivers-better-site-visits-in-2026/ | /blog/google-ads-vs-meta-ads-for-real-estate-which-delivers-better-site-visits-in-2026/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-ai-chatbots-can-qualify-leads-on-your-real-estate-website/ | /blog/how-ai-chatbots-can-qualify-leads-on-your-real-estate-website/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-ai-powered-digital-marketing-is-transforming-real-estate-brands/ | /blog/how-ai-powered-digital-marketing-is-transforming-real-estate-brands/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-customer-reviews-impact-local-seo-rankings-in-real-estate/ | /blog/how-customer-reviews-impact-local-seo-rankings-in-real-estate/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-developers-can-advertise-new-projects-without-violating-rera-rules/ | /blog/how-developers-can-advertise-new-projects-without-violating-rera-rules/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-do-images-and-videos-impact-real-estate-website-speed/ | /blog/how-do-images-and-videos-impact-real-estate-website-speed/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-google-maps-seo-can-increase-property-leads-for-realtors/ | /blog/how-google-maps-seo-can-increase-property-leads-for-realtors/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-real-estate-blogs-can-generate-organic-leads/ | /blog/how-real-estate-blogs-can-generate-organic-leads/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-real-estate-developers-can-use-website-analytics-for-better-sales-decisions/ | /blog/how-real-estate-developers-can-use-website-analytics-for-better-sales-decisions/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-rera-regulations-impact-real-estate-advertising-in-2026/ | /blog/how-rera-regulations-impact-real-estate-advertising-in-2026/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-seo-helps-build-your-real-estate-brand-authority-online/ | /blog/how-seo-helps-build-your-real-estate-brand-authority-online/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-to-choose-a-real-estate-marketing-agency-in-india-a-cmos-evaluation-framework/ | /blog/how-to-choose-a-real-estate-marketing-agency-in-india-a-cmos-evaluation-framework/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-to-choose-the-right-cms-for-your-real-estate-website/ | /blog/how-to-choose-the-right-cms-for-your-real-estate-website/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-to-create-and-optimize-google-my-business-profile-for-real-estate/ | /blog/how-to-create-and-optimize-google-my-business-profile-for-real-estate/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-to-create-high-converting-real-estate-landing-pages/ | /blog/how-to-create-high-converting-real-estate-landing-pages/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-to-do-whatsapp-marketing-for-real-estate-businesses/ | /blog/how-to-do-whatsapp-marketing-for-real-estate-businesses/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-to-find-trending-real-estate-blog-topics/ | /blog/how-to-find-trending-real-estate-blog-topics/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-to-fix-duplicate-content-issues-on-a-real-estate-website/ | /blog/how-to-fix-duplicate-content-issues-on-a-real-estate-website/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-to-generate-real-estate-leads-through-digital-marketing/ | /blog/how-to-generate-real-estate-leads-through-digital-marketing/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-to-get-a-featured-snippet-in-google/ | /blog/how-to-get-a-featured-snippet-in-google/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-to-increase-visitor-retention-rate-on-real-estate-websites/ | /blog/how-to-increase-visitor-retention-rate-on-real-estate-websites/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-to-optimize-property-listings-for-voice-search/ | /blog/how-to-optimize-property-listings-for-voice-search/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-to-optimize-real-estate-websites-for-google-search-in-2025/ | /blog/how-to-optimize-real-estate-websites-for-google-search-in-2025/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-to-rank-in-ai-search-the-complete-ai-search-optimization-guide-for-real-estate-businesses-2026/ | /blog/how-to-rank-in-ai-search-the-complete-ai-search-optimization-guide-for-real-estate-businesses-2026/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-to-run-google-ads-for-real-estate-to-get-quality-leads/ | /blog/how-to-run-google-ads-for-real-estate-to-get-quality-leads/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-to-secure-a-real-estate-website-from-spam-and-fake-leads/ | /blog/how-to-secure-a-real-estate-website-from-spam-and-fake-leads/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-to-use-ai-tools-for-real-estate-marketing/ | /blog/how-to-use-ai-tools-for-real-estate-marketing/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/how-to-use-chatgpt-to-create-seo-optimized-real-estate-blogs/ | /blog/how-to-use-chatgpt-to-create-seo-optimized-real-estate-blogs/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/instagram-vs-facebook-vs-linkedin-where-should-your-real-estate-brand-actually-be/ | /blog/instagram-vs-facebook-vs-linkedin-where-should-your-real-estate-brand-actually-be/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/is-seo-important-for-real-estate-agents-in-2026/ | /blog/is-seo-important-for-real-estate-agents-in-2026/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/key-features-to-include-in-a-real-estate-website-for-maximum-lead-conversion/ | /blog/key-features-to-include-in-a-real-estate-website-for-maximum-lead-conversion/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/landing-page-tips-for-real-estate-lead-generation/ | /blog/landing-page-tips-for-real-estate-lead-generation/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/linkedin-for-real-estate-developers-reach-nri-buyers-investors/ | /blog/linkedin-for-real-estate-developers-reach-nri-buyers-investors/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/practical-guide-to-email-marketing-for-real-estate-agents/ | /blog/practical-guide-to-email-marketing-for-real-estate-agents/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/proven-marketing-ideas-for-realtors-to-consider-in-2026/ | /blog/proven-marketing-ideas-for-realtors-to-consider-in-2026/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/real-estate-lead-generation-funnel/ | /blog/real-estate-lead-generation-funnel/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/real-estate-lead-generation-mistakes/ | /blog/real-estate-lead-generation-mistakes/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/real-estate-marketing-for-nri/ | /blog/real-estate-marketing-for-nri/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/real-estate-seo-mistakes-that-are-killing-your-traffic/ | /blog/real-estate-seo-mistakes-that-are-killing-your-traffic/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/real-estate-website-vs-property-portals/ | /blog/real-estate-website-vs-property-portals/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/retargeting-ads-for-real-estate/ | /blog/retargeting-ads-for-real-estate/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/schema-markup-for-real-estate-websites-the-structured-data-that-actually-moves-rankings/ | /blog/schema-markup-for-real-estate-websites-the-structured-data-that-actually-moves-rankings/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/seo-and-rera-compliance-how-developers-can-rank-without-making-false-claims/ | /blog/seo-and-rera-compliance-how-developers-can-rank-without-making-false-claims/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/seo-roi-in-real-estate-marketing/ | /blog/seo-roi-in-real-estate-marketing/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/seo-strategy-for-property-developers/ | /blog/seo-strategy-for-property-developers/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/social-media-trends-in-real-estate-marketing/ | /blog/social-media-trends-in-real-estate-marketing/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/step-by-step-guide-to-building-a-real-estate-website/ | /blog/step-by-step-guide-to-building-a-real-estate-website/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/strategies-to-improve-ranking-for-real-estate-industry-in-2026/ | /blog/strategies-to-improve-ranking-for-real-estate-industry-in-2026/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tag/digital-marketing/ | /blog/tag/digital-marketing/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tag/digital-marketing-for-real-estate/ | /blog/tag/digital-marketing-for-real-estate/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tag/digital-marketing-in-real-estate/ | /blog/tag/digital-marketing-in-real-estate/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tag/digital-vs-traditional-marketing-in-real-estate/ | /blog/tag/digital-vs-traditional-marketing-in-real-estate/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tag/high-converting-landing-pages/ | /blog/tag/high-converting-landing-pages/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tag/online-real-estate-lead-generation/ | /blog/tag/online-real-estate-lead-generation/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tag/real-estate-advertising/ | /blog/tag/real-estate-advertising/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tag/real-estate-digital-marketing/ | /blog/tag/real-estate-digital-marketing/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tag/real-estate-digital-marketing-agency/ | /blog/tag/real-estate-digital-marketing-agency/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tag/real-estate-landing-pages/ | /blog/tag/real-estate-landing-pages/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tag/real-estate-lead-generation/ | /blog/tag/real-estate-lead-generation/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tag/real-estate-lead-generation-mistakes/ | /blog/tag/real-estate-lead-generation-mistakes/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tag/real-estate-marketing-strategy/ | /blog/tag/real-estate-marketing-strategy/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tag/real-estate-seo/ | /blog/tag/real-estate-seo/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tag/realtor-marketing-tips/ | /blog/tag/realtor-marketing-tips/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tag/scaleacres/ | /blog/tag/scaleacres/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tag/traditional-marketing-in-real-estate/ | /blog/tag/traditional-marketing-in-real-estate/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/the-complete-real-estate-marketing-checklist-for-2026/ | /blog/the-complete-real-estate-marketing-checklist-for-2026/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/the-digital-trust-formula-every-real-estate-developer-needs-in-2026/ | /blog/the-digital-trust-formula-every-real-estate-developer-needs-in-2026/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/the-ultimate-guide-to-digital-marketing-for-real-estate-in-2025/ | /blog/the-ultimate-guide-to-digital-marketing-for-real-estate-in-2025/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/the-ultimate-guide-to-internal-linking-for-real-estate-seo/ | /blog/the-ultimate-guide-to-internal-linking-for-real-estate-seo/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/the-ultimate-youtube-seo-guide-for-real-estate-agents/ | /blog/the-ultimate-youtube-seo-guide-for-real-estate-agents/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/top-10-proven-lead-magnet-ideas-for-real-estate-agents/ | /blog/top-10-proven-lead-magnet-ideas-for-real-estate-agents/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/top-digital-marketing-strategy-for-the-real-estate-business-in-2026/ | /blog/top-digital-marketing-strategy-for-the-real-estate-business-in-2026/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/top-seo-tools-realtors-should-use-how-to-use-them/ | /blog/top-seo-tools-realtors-should-use-how-to-use-them/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/tracking-roi-in-real-estate-digital-marketing-campaigns/ | /blog/tracking-roi-in-real-estate-digital-marketing-campaigns/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/traditional-vs-digital-marketing-in-real-estate/ | /blog/traditional-vs-digital-marketing-in-real-estate/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/website-builder-for-real-estate-agents/ | /blog/website-builder-for-real-estate-agents/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/what-are-common-challenges-in-facebook-ads-for-realtors-and-how-to-solve-them/ | /blog/what-are-common-challenges-in-facebook-ads-for-realtors-and-how-to-solve-them/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/what-are-the-signs-that-your-real-estate-website-needs-a-redesign/ | /blog/what-are-the-signs-that-your-real-estate-website-needs-a-redesign/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/what-is-nap-consistency-and-why-does-it-matter-for-real-estate-seo/ | /blog/what-is-nap-consistency-and-why-does-it-matter-for-real-estate-seo/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/what-is-remarketing-for-real-estate-and-how-to-set-it-up/ | /blog/what-is-remarketing-for-real-estate-and-how-to-set-it-up/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/what-is-the-role-of-keyword-research-in-real-estate-seo-success/ | /blog/what-is-the-role-of-keyword-research-in-real-estate-seo-success/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/what-realtors-need-to-know-before-investing-in-seo/ | /blog/what-realtors-need-to-know-before-investing-in-seo/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/whatsapp-marketing-for-real-estate-how-developers-are-using-it-to-qualify-and-convert-leads/ | /blog/whatsapp-marketing-for-real-estate-how-developers-are-using-it-to-qualify-and-convert-leads/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/why-backlinks-matter-for-real-estate-websites-and-how-to-build-them/ | /blog/why-backlinks-matter-for-real-estate-websites-and-how-to-build-them/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/why-buyers-cant-find-your-project-on-google-and-how-to-fix-it/ | /blog/why-buyers-cant-find-your-project-on-google-and-how-to-fix-it/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/why-buyers-ignore-your-real-estate-ads-even-with-a-big-marketing-budget/ | /blog/why-buyers-ignore-your-real-estate-ads-even-with-a-big-marketing-budget/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/why-do-real-estate-businesses-must-focus-on-mobile-first-marketing/ | /blog/why-do-real-estate-businesses-must-focus-on-mobile-first-marketing/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/why-do-real-estate-businesses-need-digital-marketing-in-2026/ | /blog/why-do-real-estate-businesses-need-digital-marketing-in-2026/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/why-real-estate-businesses-need-a-professional-website/ | /blog/why-real-estate-businesses-need-a-professional-website/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/why-real-estate-websites-should-include-testimonials-reviews-and-rera-information/ | /blog/why-real-estate-websites-should-include-testimonials-reviews-and-rera-information/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/why-regular-maintenance-is-important-for-real-estate-websites/ | /blog/why-regular-maintenance-is-important-for-real-estate-websites/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/why-ui-ux-matters-in-real-estate-website-development/ | /blog/why-ui-ux-matters-in-real-estate-website-development/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/why-website-speed-and-security-matter-for-real-estate-professionals/ | /blog/why-website-speed-and-security-matter-for-real-estate-professionals/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/why-your-ad-budget-is-wasted-if-your-website-loads-slow/ | /blog/why-your-ad-budget-is-wasted-if-your-website-loads-slow/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/ca/ | /ca/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/careers/ | /careers/ | PASS | PASS | PASS | PASS | capture covered 83% of the live page's visible words (forms/widgets) |
| https://scaleacres.com/case-studies/ | /case-studies/ | PASS | PASS | REVIEW REQUIRED | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa']; internal links missing: ['/case-studies'] |
| https://scaleacres.com/contact-us/ | /contact-us/ | PASS | PASS | PASS | PASS | capture covered 84% of the live page's visible words (forms/widgets) |
| https://scaleacres.com/digital-marketing-agency-for-real-estate-in-dehradun/ | /digital-marketing-agency-for-real-estate-in-dehradun/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-abu-dhabi/ | /digital-marketing-company-for-real-estate-in-abu-dhabi/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-auckland/ | /digital-marketing-company-for-real-estate-in-auckland/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-bangkok/ | /digital-marketing-company-for-real-estate-in-bangkok/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-doha/ | /digital-marketing-company-for-real-estate-in-doha/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-jeddah/ | /digital-marketing-company-for-real-estate-in-jeddah/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-johor/ | /digital-marketing-company-for-real-estate-in-johor/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-kuala-lumpur-kl/ | /digital-marketing-company-for-real-estate-in-kuala-lumpur-kl/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-london/ | /digital-marketing-company-for-real-estate-in-london/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-manchester/ | /digital-marketing-company-for-real-estate-in-manchester/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-melbourne/ | /digital-marketing-company-for-real-estate-in-melbourne/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-neom/ | /digital-marketing-company-for-real-estate-in-neom/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-penang/ | /digital-marketing-company-for-real-estate-in-penang/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-phuket/ | /digital-marketing-company-for-real-estate-in-phuket/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-riyadh/ | /digital-marketing-company-for-real-estate-in-riyadh/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-sydney/ | /digital-marketing-company-for-real-estate-in-sydney/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-toronto/ | /digital-marketing-company-for-real-estate-in-toronto/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-vancouver/ | /digital-marketing-company-for-real-estate-in-vancouver/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-company-for-real-estate-in-wellington/ | /digital-marketing-company-for-real-estate-in-wellington/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/digital-marketing-services-for-real-estate-in-mohali/ | /digital-marketing-services-for-real-estate-in-mohali/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/facebook-ads-agency/ | /facebook-ads-agency/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/id/ | /id/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/ | / | REVIEW REQUIRED | PASS | REVIEW REQUIRED | REVIEW REQUIRED | Approved redesigned homepage: title and meta description identical; body content intentionally replaced by the approved design (see homepage report) |
| https://scaleacres.com/my/ | /my/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/nz/ | /nz/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/our-services/ | /our-services/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/our-team/ | /our-team/ | PASS | PASS | PASS | PASS | capture covered 90% of the live page's visible words (forms/widgets) |
| https://scaleacres.com/our-work/ | /our-work/ | PASS | PASS | PASS | PASS | capture covered 85% of the live page's visible words (forms/widgets) |
| https://scaleacres.com/privacy-policy/ | /privacy-policy/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/qa/ | /qa/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/real-estate-branding-agency/ | /real-estate-branding-agency/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-agency-in-ahmedabad/ | /real-estate-digital-marketing-agency-in-ahmedabad/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-agency-in-amritsar/ | /real-estate-digital-marketing-agency-in-amritsar/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-agency-in-ayodhya/ | /real-estate-digital-marketing-agency-in-ayodhya/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-agency-in-chandigarh/ | /real-estate-digital-marketing-agency-in-chandigarh/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-agency-in-dholera/ | /real-estate-digital-marketing-agency-in-dholera/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-agency-in-dubai/ | /real-estate-digital-marketing-agency-in-dubai/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/real-estate-digital-marketing-agency-in-faridabad/ | /real-estate-digital-marketing-agency-in-faridabad/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-agency-in-ghaziabad/ | /real-estate-digital-marketing-agency-in-ghaziabad/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-agency-in-goa/ | /real-estate-digital-marketing-agency-in-goa/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-agency-in-haridwar/ | /real-estate-digital-marketing-agency-in-haridwar/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-agency-in-hyderabad/ | /real-estate-digital-marketing-agency-in-hyderabad/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-agency-in-jaipur/ | /real-estate-digital-marketing-agency-in-jaipur/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-agency-in-kochi/ | /real-estate-digital-marketing-agency-in-kochi/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-agency-in-lucknow/ | /real-estate-digital-marketing-agency-in-lucknow/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-agency-in-manali/ | /real-estate-digital-marketing-agency-in-manali/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-agency-in-nainital/ | /real-estate-digital-marketing-agency-in-nainital/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-agency-in-rishikesh/ | /real-estate-digital-marketing-agency-in-rishikesh/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-company-in-indore/ | /real-estate-digital-marketing-company-in-indore/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-company-in-kolkata/ | /real-estate-digital-marketing-company-in-kolkata/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-digital-marketing-company-in-zirakpur/ | /real-estate-digital-marketing-company-in-zirakpur/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-lead-generation-agency/ | /real-estate-lead-generation-agency/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-marketing-agency-in-nagpur/ | /real-estate-marketing-agency-in-nagpur/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-marketing-bangalore/ | /real-estate-marketing-bangalore/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/real-estate-marketing-company-in-coimbatore/ | /real-estate-marketing-company-in-coimbatore/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-marketing-delhi/ | /real-estate-marketing-delhi/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-marketing-gurgaon/ | /real-estate-marketing-gurgaon/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-marketing-mumbai/ | /real-estate-marketing-mumbai/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/real-estate-marketing-noida/ | /real-estate-marketing-noida/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-marketing-pune/ | /real-estate-marketing-pune/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-ppc-service/ | /real-estate-ppc-service/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-seo-service/ | /real-estate-seo-service/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/real-estate-web-development/ | /real-estate-web-development/ | PASS | PASS | PASS | PASS | capture covered 93% of the live page's visible words (forms/widgets) |
| https://scaleacres.com/sa/ | /sa/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/sg/ | /sg/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/social-media-marketing-agency/ | /social-media-marketing-agency/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/terms-conditions/ | /terms-conditions/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/th/ | /th/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/uae/ | /uae/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/uk/ | /uk/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/us/ | /us/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/yugen-case-study/ | /yugen-case-study/ | PASS | PASS | PASS | PASS | capture covered 92% of the live page's visible words (forms/widgets) |
| https://scaleacres.com/au/digital-marketing-company-for-real-estate-in-melbourne/ | /au/digital-marketing-company-for-real-estate-in-melbourne/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/au/digital-marketing-company-for-real-estate-in-sydney/ | /au/digital-marketing-company-for-real-estate-in-sydney/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/blog/2025/10/08/ | /blog/2025/10/08/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/10/09/ | /blog/2025/10/09/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/10/10/ | /blog/2025/10/10/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/10/11/ | /blog/2025/10/11/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/10/14/ | /blog/2025/10/14/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/10/16/ | /blog/2025/10/16/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/10/18/ | /blog/2025/10/18/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/10/21/ | /blog/2025/10/21/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/10/23/ | /blog/2025/10/23/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/10/24/ | /blog/2025/10/24/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/10/25/ | /blog/2025/10/25/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/10/27/ | /blog/2025/10/27/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/10/28/ | /blog/2025/10/28/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/01/ | /blog/2025/11/01/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/04/ | /blog/2025/11/04/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/07/ | /blog/2025/11/07/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/08/ | /blog/2025/11/08/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/10/ | /blog/2025/11/10/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/11/ | /blog/2025/11/11/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/12/ | /blog/2025/11/12/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/13/ | /blog/2025/11/13/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/14/ | /blog/2025/11/14/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/17/ | /blog/2025/11/17/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/18/ | /blog/2025/11/18/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/19/ | /blog/2025/11/19/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/20/ | /blog/2025/11/20/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/21/ | /blog/2025/11/21/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/22/ | /blog/2025/11/22/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/24/ | /blog/2025/11/24/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/25/ | /blog/2025/11/25/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/26/ | /blog/2025/11/26/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/27/ | /blog/2025/11/27/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/28/ | /blog/2025/11/28/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/11/29/ | /blog/2025/11/29/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/12/01/ | /blog/2025/12/01/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/12/03/ | /blog/2025/12/03/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/12/08/ | /blog/2025/12/08/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/12/09/ | /blog/2025/12/09/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/12/20/ | /blog/2025/12/20/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/12/22/ | /blog/2025/12/22/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/12/23/ | /blog/2025/12/23/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/12/24/ | /blog/2025/12/24/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2025/12/26/ | /blog/2025/12/26/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/01/03/ | /blog/2026/01/03/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/01/05/ | /blog/2026/01/05/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/01/06/ | /blog/2026/01/06/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/01/08/ | /blog/2026/01/08/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/01/09/ | /blog/2026/01/09/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/01/12/ | /blog/2026/01/12/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/01/15/ | /blog/2026/01/15/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/01/16/ | /blog/2026/01/16/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/01/17/ | /blog/2026/01/17/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/01/21/ | /blog/2026/01/21/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/01/24/ | /blog/2026/01/24/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/01/29/ | /blog/2026/01/29/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/02/03/ | /blog/2026/02/03/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/02/05/ | /blog/2026/02/05/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/02/07/ | /blog/2026/02/07/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/02/16/ | /blog/2026/02/16/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/02/18/ | /blog/2026/02/18/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/02/20/ | /blog/2026/02/20/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/02/23/ | /blog/2026/02/23/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/03/03/ | /blog/2026/03/03/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/03/12/ | /blog/2026/03/12/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/03/16/ | /blog/2026/03/16/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/03/18/ | /blog/2026/03/18/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/03/20/ | /blog/2026/03/20/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/03/26/ | /blog/2026/03/26/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/03/29/ | /blog/2026/03/29/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/03/31/ | /blog/2026/03/31/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/04/01/ | /blog/2026/04/01/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/04/03/ | /blog/2026/04/03/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/04/28/ | /blog/2026/04/28/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/06/30/ | /blog/2026/06/30/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/07/02/ | /blog/2026/07/02/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/07/04/ | /blog/2026/07/04/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/07/06/ | /blog/2026/07/06/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/07/10/ | /blog/2026/07/10/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/07/11/ | /blog/2026/07/11/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/07/14/ | /blog/2026/07/14/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/07/16/ | /blog/2026/07/16/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/07/18/ | /blog/2026/07/18/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/07/21/ | /blog/2026/07/21/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/07/23/ | /blog/2026/07/23/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/07/25/ | /blog/2026/07/25/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/07/28/ | /blog/2026/07/28/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/07/29/ | /blog/2026/07/29/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/08/01/ | /blog/2026/08/01/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/08/04/ | /blog/2026/08/04/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/08/07/ | /blog/2026/08/07/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/08/11/ | /blog/2026/08/11/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/09/03/ | /blog/2026/09/03/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/2026/10/07/ | /blog/2026/10/07/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/blog/guide-to-real-estate-seo-for-property-developers/ | /blog/guide-to-real-estate-seo-for-property-developers/ | PASS | PASS | PASS | PASS |  |
| https://scaleacres.com/ca/digital-marketing-company-for-real-estate-in-toronto/ | /ca/digital-marketing-company-for-real-estate-in-toronto/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/ca/digital-marketing-company-for-real-estate-in-vancouver/ | /ca/digital-marketing-company-for-real-estate-in-vancouver/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/casestudy/our-case-one-goa/ | — | N/A | N/A | N/A | N/A | Live URL answers 404 (not a page); not recreated |
| https://scaleacres.com/how-ai-chatbots-can-qualify-leads-on-your-real-estate-website/ | — | N/A | N/A | N/A | N/A | Live URL answers 404 (not a page); not recreated |
| https://scaleacres.com/id/digital-marketing-company-for-real-estate-in-bali/ | /id/digital-marketing-company-for-real-estate-in-bali/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/id/digital-marketing-company-for-real-estate-in-jakarta/ | /id/digital-marketing-company-for-real-estate-in-jakarta/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/my/digital-marketing-company-for-real-estate-in-johor/ | /my/digital-marketing-company-for-real-estate-in-johor/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/my/digital-marketing-company-for-real-estate-in-kuala-lumpur-kl/ | /my/digital-marketing-company-for-real-estate-in-kuala-lumpur-kl/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/my/digital-marketing-company-for-real-estate-in-penang/ | /my/digital-marketing-company-for-real-estate-in-penang/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/nz/digital-marketing-company-for-real-estate-in-auckland/ | /nz/digital-marketing-company-for-real-estate-in-auckland/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/nz/digital-marketing-company-for-real-estate-in-wellington/ | /nz/digital-marketing-company-for-real-estate-in-wellington/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/ph/ | /ph/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/qa/digital-marketing-company-for-real-estate-in-doha/ | /qa/digital-marketing-company-for-real-estate-in-doha/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/real-estate-marketing-Bangalore/ | /real-estate-marketing-Bangalore/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/sa/digital-marketing-company-for-real-estate-in-jeddah/ | /sa/digital-marketing-company-for-real-estate-in-jeddah/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/sa/digital-marketing-company-for-real-estate-in-neom/ | /sa/digital-marketing-company-for-real-estate-in-neom/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/sa/digital-marketing-company-for-real-estate-in-riyadh/ | /sa/digital-marketing-company-for-real-estate-in-riyadh/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/th/digital-marketing-company-for-real-estate-in-bangkok/ | /th/digital-marketing-company-for-real-estate-in-bangkok/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/th/digital-marketing-company-for-real-estate-in-phuket/ | /th/digital-marketing-company-for-real-estate-in-phuket/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/uae/digital-marketing-company-for-real-estate-in-abu-dhabi/ | /uae/digital-marketing-company-for-real-estate-in-abu-dhabi/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/uae/real-estate-digital-marketing-agency-in-dubai/ | /uae/real-estate-digital-marketing-agency-in-dubai/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/uk/digital-marketing-company-for-real-estate-in-london/ | /uk/digital-marketing-company-for-real-estate-in-london/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/uk/digital-marketing-company-for-real-estate-in-manchester/ | /uk/digital-marketing-company-for-real-estate-in-manchester/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/us/digital-marketing-company-for-real-estate-in-miami/ | /us/digital-marketing-company-for-real-estate-in-miami/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/us/digital-marketing-company-for-real-estate-in-new-york/ | /us/digital-marketing-company-for-real-estate-in-new-york/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/us/digital-marketing-company-for-real-estate-in-texas/ | /us/digital-marketing-company-for-real-estate-in-texas/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/vn/ | /vn/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/vn/digital-marketing-company-for-real-estate-in-hanoi/ | /vn/digital-marketing-company-for-real-estate-in-hanoi/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |
| https://scaleacres.com/vn/digital-marketing-company-for-real-estate-in-ho-chi-minh-city/ | /vn/digital-marketing-company-for-real-estate-in-ho-chi-minh-city/ | PASS | PASS | PASS | PASS | broken live link fixed: ['/casestudy/our-case-one-goa'] → ['/blog/casestudy/our-case-one-goa'] |