ScaleAcres homepage v8: ready for Netlify

Pages
  /                 index.html       the homepage
  /landing          landing.html     ad landing page
  /free-audit       free-audit.html  free-audit lead magnet page

Deploy (drag and drop)
  1. Unzip this file.
  2. Open app.netlify.com > Add new site > Deploy manually.
  3. Drag the unzipped folder (the one containing index.html) onto the page.

Notes
  - Staging only: every page carries "noindex", so Google will not list it.
    Remove the robots meta tag and the X-Robots-Tag header in netlify.toml at launch.
  - The forms check the fields but do not send anything yet.
    To receive leads, connect them to Netlify Forms, your email or your CRM.
