# Unverified details — must be confirmed before go-live

**Updated 21 Oct 2026 after brochure integration.** Items 5, 6, 7, 8, 9 and 10 below are now verified against the brochure and are kept only for the record (struck through).

Items marked `verified: false` in `content/project.ts`, plus environment items.

1. **Starting price ₹8.31 Cr\*** — from the official page snippet at audit time. Replace from the current cost sheet (`project.headline.startingPrice`).
2. **Possession: September 2032** — official page snippet; confirm against RERA timeline.
3. **Configuration naming** — "3 & 4 BHK" vs "3.5 & 4.5 BHK" seen on two Godrej pages.
4. **Carpet / super areas and per-configuration prices** — left as "On request". Aggregator figures conflict and were not used.
5. ~~**Brochure-sourced specifications** (2 per core, private lift lobbies, 3.4 m, 380–600 sq ft, Schüco, Villeroy & Boch, 5 lifts) — from the brief's page table; confirm wording against brochure p.44–49.~~ ✔ verified against brochure
6. ~~**Eight Rays copy** — the eight names come from the brief; the descriptive copy under each ray is marketing copy written from verified facts, not brochure text.~~ ✔ verified against brochure
7. ~~**Amenity list** beyond the onsen and rooftop pools — confirm against brochure p.33–36.~~ ✔ verified against brochure
8. ~~**"No overlooking towers"** — appears in the brief; not independently verified.~~ ✔ verified against brochure
9. ~~**Location distances/times** — third-party approximations; replace with the brochure map table.~~ ✔ verified against brochure
10. ~~**Godrej Group heritage copy** ("since 1897") — general knowledge; replace with approved corporate copy.~~ ✔ verified against brochure
11. **Walkthrough video** — no official URL verified; section stays in pending mode.
12. **Image republication permission** — none on file; all assets `not-supplied`.
13. **Advertiser identity, agent RERA, phone, WhatsApp, email, analytics IDs** — all empty by design; set in `.env.local`.
14. **Tower and floor count** — four towers per listings, G+30 vs G+31; not displayed.
15. ~~**Brochure typography**~~ ✔ inspected: TheFuture / Helvetica Light / Raleway; Jost + Manrope chosen as licensed matches.
16. **Image republication permission** — brochure assets are now integrated with `approval: 'pending'`; file the written permission and flip to `approved` before go-live.
